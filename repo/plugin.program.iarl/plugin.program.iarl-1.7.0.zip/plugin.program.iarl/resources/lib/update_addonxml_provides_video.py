from util import *

update_addonxml('video game')